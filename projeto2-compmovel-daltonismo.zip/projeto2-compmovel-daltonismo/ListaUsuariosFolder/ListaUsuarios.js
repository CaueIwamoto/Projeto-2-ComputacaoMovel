//Imports:
import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

//Criação Lista Usuarios:
const ListaUsuarios = () => {
  const [usuarios, setUsuarios] = useState([]);

//Parte que espera armazenamento local:
  useEffect(() => {
  const carregarUsuarios = async () => {
    try {
      const keys = await AsyncStorage.getAllKeys();
      const entries = await AsyncStorage.multiGet(keys);

      const lista = entries
        .filter(([key, _]) => key.startsWith('user_'))
        .map(([key, senha]) => ({
        usuario: key.replace('user_', ''),
        senha,
      }));

    setUsuarios(lista);
  } catch (error) {
    console.error('Erro ao carregar usuários:', error);
  }
};

    carregarUsuarios();
  }, []);

  const renderItem = ({ item }) => (
    <View style={styles.item}>
      <Text style={styles.nome}>Usuário: {item.usuario}</Text>
      <Text style={styles.senha}>Senha: {'*'.repeat(item.senha.length)}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Usuários cadastrados no sistema</Text>
      <FlatList
        data={usuarios}
        keyExtractor={(item, index) => index.toString()}
        renderItem={renderItem}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  titulo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  item: {
    padding: 10,
    marginBottom: 10,
    backgroundColor: '#e0e0e0',
    borderRadius: 8,
  },
  nome: {
    fontSize: 16,
  },
  senha: {
    fontSize: 16,
    color: '#555',
  },
});

export default ListaUsuarios;

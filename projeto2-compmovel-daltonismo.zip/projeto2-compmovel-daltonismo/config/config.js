// Import the functions you need from the SDKs you need
import firebase from "firebase";


// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDSJftqzNlLwTI7RC_P_i5150PGqfwmWmY",
  authDomain: "projeto2-compmovel.firebaseapp.com",
  databaseURL: "https://projeto2-compmovel-default-rtdb.firebaseio.com",
  projectId: "projeto2-compmovel",
  storageBucket: "projeto2-compmovel.firebasestorage.app",
  messagingSenderId: "844244279403",
  appId: "1:844244279403:web:d88422d9f358cc8442512e",
  measurementId: "G-SKS233R533"
};


if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

export default firebase;